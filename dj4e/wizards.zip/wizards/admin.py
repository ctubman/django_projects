from django.contrib import admin
from wizards.models import Wizard, House

admin.site.register(Wizard)
admin.site.register(House)
# Register your models here.

